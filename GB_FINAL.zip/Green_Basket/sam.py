from datetime import datetime
order_date = datetime.now().strftime('%d-%m-%Y')
order_day = datetime.now().strftime('%A')
print(order_date,order_day)