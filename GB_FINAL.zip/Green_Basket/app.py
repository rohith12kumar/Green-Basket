from flask import Flask, render_template, request, redirect, url_for, jsonify, session ,send_file,flash
from pymongo import MongoClient
from bson import ObjectId
import gridfs
from bson import ObjectId
from io import BytesIO
import logging
from datetime import datetime
import time
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import random
import string
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'yguhyugikjutyhijlkutgyihuij'

client = MongoClient('mongodb://localhost:27017/')
db = client['Green_Basket']
users_collection = db['users']
products_collection = db['products']
cart_collection = db['cart']
orders_collection = db['orders']
fs = gridfs.GridFS(db)
feedback_collection = db['feedback']

app.config['UPLOAD_FOLDER'] = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'static/uploads/')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  
app.secret_key = 'your_secret_key'  


os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)


OTP_LENGTH = 6
SENDER_EMAIL = 'greenbasketweb.team@gmail.com'
SMTP_SERVER = 'smtp.gmail.com'
SMTP_PORT = 587
SMTP_USERNAME = 'greenbasketweb.team@gmail.com'
SMTP_PASSWORD = 'nkuc zggc ytfx dbcu'
otp_storage = {}


@app.route('/')
def home():
    return render_template('index.html')

def generate_invoiceid():
    return ''.join(random.choices(string.digits, k=8))

def generate_otp():
    return ''.join(random.choices(string.digits, k=OTP_LENGTH))

@app.route('/customerpagerender')
def customerpagerender():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"error": "User Not Logged In"})
    user_data=users_collection.find_one({'_id':ObjectId(user_id)})
    user_name=user_data['name']
    user_email=user_data['email']
    user_location=user_data['location']
    profile_image = user_data['profile_image'].strip()
    ordered_count = orders_collection.count_documents({
    'user_id': user_id,
    'status': {'$in': ['ordered', 'confirmed', 'pickedup']}})
    received_count = orders_collection.count_documents({'user_id':user_id,'status':'delivered'})
    return render_template('customerpage.html',ordered_count=ordered_count,profile_image=profile_image,received_count=received_count,total_count=received_count+ordered_count,user_id=user_id,user_email=user_email,user_name=user_name,user_location=user_location.title())

@app.route('/agentpagerender')
def agentpagerender():
    agent_id = session.get('user_id')
    pending_count = orders_collection.count_documents({'status': 'confirmed'})
    picked_up_count = orders_collection.count_documents({'status': 'pickedup', 'agent_id': str(agent_id)})
    delivered_orders = orders_collection.find({'status': 'delivered', 'agent_id': str(agent_id)})
    delivered_count = orders_collection.count_documents({'status': 'delivered', 'agent_id': str(agent_id)})
    total_delivery_charges = sum(order.get('delivery_charges', 0) for order in delivered_orders)
    user_data=users_collection.find_one({'_id':ObjectId(agent_id)})
    user_name=user_data['name']
    user_email=user_data['email']
    profile_image = user_data['profile_image'].strip()

    return render_template('agentpage.html', 
                           pending_count=pending_count,
                           picked_up_count=picked_up_count,
                           delivered_count=delivered_count,
                           profile_image=profile_image,
                           total_delivery_charges=total_delivery_charges,
                           user_name=user_name,user_email=user_email)

@app.route('/adminpagerender')
def adminpagerender():
    user_data=list(users_collection.find({}))
    orders_data=list(orders_collection.find({'status':'delivered'}))
    farmer_count=0
    user_count=0
    agents_count=0
    del_income=0
    user_income=0
    
    for order in orders_data:
        del_income+=float(order['delivery_charges'])
        user_income+=float(order['farmer_amount'])


    for user in user_data:
        if user['role']=='customer':
            user_count+=1
        if user['role']=='farmer':
            farmer_count+=1
        if user['role']=='delivery_agent':
            agents_count+=1
    
    counted_del_income = del_income * 0.15
    counted_user_income = user_income * 0.08
    total_income = counted_del_income + counted_user_income
    formatted_del_income =  "{:.2f}".format(counted_del_income)
    formatted_user_income = "{:.2f}".format(counted_user_income)
    formatted_total_income = "{:.2f}".format(total_income)
   

    return render_template('adminpage.html',
                           u_income=formatted_user_income,
                           d_income=formatted_del_income,
                           total_income=formatted_total_income,
                           farmer_count=farmer_count,
                           user_count=user_count,
                           agents_count=agents_count
                           )

@app.route('/farmerpagerender')
def farmerpagerender():
    farmer_id = session.get('user_id')

    # Initialize counters and revenue
    quantity_sold = 0
    quantity_remaining = 0
    total_revenue = 0.0
    accepted_count = 0
    pending_count = 0
    total_orders = 0

    user_data=users_collection.find_one({'_id':ObjectId(farmer_id)})
    user_name=user_data['name']
    user_email=user_data['email']

    # Fetch all orders related to the farmer
    orders = orders_collection.find({'cart_items.farmer_id': str(farmer_id)})

    accepted_order_ids = set()
    pending_order_ids = set()

    for order in orders:
        total_orders += 1

        for item in order['cart_items']:
            if item['farmer_id'] == str(farmer_id):
                if item['current_status'] == 'accepted':
                    accepted_order_ids.add(order['_id'])
                    quantity_sold += item['quantity']
                    total_revenue += item['price'] * item['quantity']
                elif item['current_status'] == 'ordered':
                    pending_order_ids.add(order['_id'])

    accepted_count = len(accepted_order_ids)
    pending_count = len(pending_order_ids)
    products = products_collection.find({'farmer_id': str(farmer_id)})


    total_stock = 0
    for product in products:
        total_stock += product.get('quantity') 

    quantity_remaining = total_stock
    profile_image = user_data['profile_image'].strip()

    return render_template(
        'farmerpage.html',
        quantity_sold=float("{:.2f}".format(quantity_sold)),
        quantity_remaining=float("{:.2f}".format(quantity_remaining)),
        total_revenue=float("{:.2f}".format(total_revenue)),
        accepted_count=accepted_count,
        pending_count=pending_count,
        profile_image=profile_image,
        total_orders=total_orders,
        total_stock=total_stock,
        user_email=user_email,
        user_name=user_name
    )


@app.route('/signuppagerender')
def signuppagerender():
    return render_template('signup.html')

@app.route('/loginpagerender')
def loginpagerender():
    return render_template('login.html')

@app.route('/signup', methods=['POST'])
def signup_render():
    name = request.form.get('name')
    email = request.form.get('email')
    role = request.form.get('role')
    password = request.form.get('password')
    phone = request.form.get('mobile')
    location = request.form.get('location')
    area=request.form.get('area')


    existing_user = users_collection.find_one({'email': email})
    if existing_user:
        return jsonify({"message": "User already exists"})

    hashed_password = generate_password_hash(password)
    user = {
        'name': name,
        'email': email,
        'role': role,
        'area':area,
        'location':location,
        'phone':phone,
        'blocked':False,
        'profile_image':"",
        'password': hashed_password
    }
    users_collection.insert_one(user)
    return jsonify({"success":True, "message": "User registered successfully"})

@app.route('/login', methods=['POST'])
def login():
    email = request.form.get('email')
    password = request.form.get('password')

    user = users_collection.find_one({'email': email})

    if email == "admin@gmail.com" and password == "admin":
        return jsonify({"success": "admin"})

    if user:
        if user.get('blocked'):
            return jsonify({"message": "Your account is on hold, please try after sometime."})

        if check_password_hash(user['password'], password):
            session['user_id'] = str(user['_id'])
            session['role'] = user['role']
            return jsonify({"success": user['role']})

    return jsonify({"message": "Invalid credentials"})

@app.route('/send_otp', methods=['POST'])
def send_otp():
    data = request.json
    email = data.get('email')
    fullname = data.get('fullName')

    if users_collection.find_one({"email": email}):
        return jsonify({'success': False, 'message': 'Email already registered'})

    otp = generate_otp()
    otp_storage[email] = {'otp': otp, 'fullname': fullname}
    send_otp_email(email, fullname, otp)

    return jsonify({'success': True})

@app.route('/verify_otp', methods=['POST'])
def verify_otp():
    data = request.json
    email = data.get('email')
    otp = data.get('otp')
    stored_data = otp_storage.get(email)

    if stored_data and stored_data['otp'] == otp:
        del otp_storage[email]
        return jsonify({'success': True})
    else:
        return jsonify({'success': False})

def send_otp_email(email,fullname, otp):
    msg = MIMEMultipart()
    msg['From'] = SENDER_EMAIL
    msg['To'] = email
    msg['Subject'] = 'Your OTP Verification Code from Green Basket'

    body = f"""
    <html>
      <body>
        <p>Dear {fullname},</p>
        <p>Thank you for using Green Basket!</p>
        <p>To complete your signup process, please use the following One-Time Password (OTP) for verification:</p>
        <p>Your OTP Code: <h2><strong>{otp}</strong></h2></p>
        <p>Please enter this code on the Green Basket signup page to verify your email address.</p>
        <p>If you did not initiate this request, please ignore this email.</p>
        <p>Thank you for choosing Green Basket!</p>
        <p>Best regards,<br>The Green Basket Team</p>
      </body>
    </html>
    """
    msg.attach(MIMEText(body, 'html'))

    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
        server.starttls()
        server.login(SMTP_USERNAME, SMTP_PASSWORD)
        server.sendmail(SENDER_EMAIL, email, msg.as_string())

def send_reply_to_email(feedback,reply):
    msg = MIMEMultipart()
    msg['From'] = SENDER_EMAIL
    msg['To'] = feedback['email']
    msg['Subject'] = 'Reply to Your Comment'

    body = f"""
    <html>
      <body>
        <p>Dear {feedback['name']},</p>
        <p>Thank you for your comment!</p>
        <p>Here is our response:</p>
        <div style="border:solid 1px rgb(66, 66, 66); border-radius:3px; background-color:grey; padding:5px;">
        <strong>{reply}</strong>
        </div>
        <p>If you have any further questions, feel free to reach out.</p>
        <p>Best regards,<br>The Green Basket Team</p>
      </body>
    </html>
    """
    msg.attach(MIMEText(body, 'html'))

    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
        server.starttls()
        server.login(SMTP_USERNAME, SMTP_PASSWORD)
        server.sendmail(SENDER_EMAIL, feedback['email'], msg.as_string())

@app.route('/update_user/<user_id>', methods=['POST'])
def update_user(user_id):
    if 'user_id' not in session:
        return jsonify({'error': 'User not logged in'}), 403

    
    phone = request.form.get('phone')
    location = request.form.get('location')
    result = users_collection.update_one(
        {'_id': ObjectId(user_id)}, 
        {'$set': {
            'phone': phone,
            'location': location
        }}
    )
    cart_collection.delete_many({'user_id': user_id})

    if result.modified_count > 0:
        flash('User data updated successfully!', 'success')  
    else:
        flash('No changes made or user not found.', 'error')

    return redirect(url_for('customerpagerender'))

@app.route("/add_product", methods=["POST"])
def add_product():
    user_id = session.get('user_id')
    product_name = request.form.get("productName")
    product_quantity = request.form.get("productQuantity")
    product_price = request.form.get("productPrice")
    product_image = request.files.get("productImage")
    farmer_data=users_collection.find_one({'_id' : ObjectId(user_id)})
    farmer_location=farmer_data['location']
    farmer_area=farmer_data['area']
    if product_image:
        image_id = fs.put(product_image.read(), filename=product_image.filename)
    else:
        image_id = None

    product_data = {
        "name": product_name,
        "quantity": float(product_quantity),
        "farmer_id":user_id,
        "product_location":farmer_location,
        'product_area':farmer_area,
        "price": float(product_price),
        "image_id": image_id
    }
    products_collection.insert_one(product_data)

    return jsonify({"message": "Product added successfully!"})


@app.route("/get_products", methods=["GET"])
def get_products():
    user_id = session.get('user_id')
    user_data=users_collection.find_one({'_id':ObjectId(user_id)})
    user_location=user_data['location']
    products = list(products_collection.find({'product_location':user_location}))  
    product_list = []
    

    for product in products:
        id =product['_id']
        product_data = {
            "_id":str(id),
            "name": product["name"],
            "quantity": product["quantity"],
            "price": product["price"],
            "farmer_id": product['farmer_id'],
            "product_area":product['product_area'],
            "image_id": str(product["image_id"]) if product["image_id"] else None
        }
        product_list.append(product_data)

    product_length=len(product_list)
    return jsonify({"products": product_list,"length":product_length})

@app.route("/get_farmer_products", methods=["GET"])
def get_farmer_products():
    user_id = session.get('user_id')
    products = list(products_collection.find({'farmer_id':user_id}))  
    product_list = []
    

    for product in products:
        id =product['_id']
        product_data = {
            "_id":str(id),
            "name": product["name"],
            "quantity": product["quantity"],
            "price": product["price"],
            "farmer_id": product['farmer_id'],
            "image_id": str(product["image_id"]) if product["image_id"] else None
        }
        product_list.append(product_data)


    return jsonify({"products": product_list})

@app.route("/get_image/<image_id>")
def get_image(image_id):
    try:
        image_file = fs.get(ObjectId(image_id))
        return send_file(BytesIO(image_file.read()), mimetype="image/jpeg")
    except Exception as e:
        logging.error(f"Error retrieving image {image_id}: {e}")
        return jsonify({"error": "Image not found"}), 404
    

@app.route("/add_to_cart", methods=["POST"])
def add_to_cart():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"message": "User not logged in"}), 401
    data = request.get_json()
    product_id = data.get('productId')
    quantity = float(data.get('quantity'))

    product = products_collection.find_one({"_id": ObjectId(product_id)})
    product['image_id']=str(product['image_id'])
    if not product:
        return jsonify({"message": "Product not found"}), 404
    
    print(quantity,product['quantity'])
   
    existing_cart_item = cart_collection.find_one({"user_id": user_id, "product_id": product_id})
    if existing_cart_item:
        if (float(existing_cart_item['quantity']) + quantity ) > float(product['quantity']):
            return jsonify({"message": f"Product quantity not available, Already {existing_cart_item['quantity']}kg is in cart"}), 404
        cart_collection.update_one(
            {"user_id": user_id, "product_id": product_id},
            {"$set": {"quantity": float(existing_cart_item['quantity']) + quantity}}
        )
    else:
        cart_item = {
            "user_id": user_id,
            "image_id": product['image_id'],
            "product_id": product_id,
            "farmer_id":product['farmer_id'],
            "product_area":product['product_area'],
            "name": product['name'],
            "price": product['price'],
            "quantity": quantity
        }
        print("cartitem",cart_item)
        cart_collection.insert_one(cart_item)

    return jsonify({"message": "Item added to cart successfully!"})


@app.route('/get_cart', methods=['GET'])
def get_cart():
    try:
        user_id = session.get('user_id')
        cart_items = cart_collection.find({'user_id':user_id})
        cart_items_list = []
        for item in cart_items:
            item['_id'] = str(item['_id'])  # Convert ObjectId to string
            cart_items_list.append(item)
        print(cart_items_list)
        return jsonify(cart_items_list), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/remove_from_cart/<product_id>', methods=['DELETE'])
def remove_from_cart(product_id):
    try:
        result = cart_collection.delete_one({"product_id": product_id})

        if result.deleted_count > 0:
            return jsonify({"message": "Item removed from cart."}), 200
        else:
            return jsonify({"message": "Item not found in cart."}), 404
    except Exception as e:
        return jsonify({"message": str(e)}), 500
    
@app.route('/checkout', methods=["POST"])
def checkout():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({"message": "User not logged in"}), 401

    data = request.get_json()
    user_data=users_collection.find_one({'_id':ObjectId(user_id)})
    items_total = sum(float(item['price']) * float(item['quantity']) for item in data.get("cart"))
    items_total = float("{:.2f}".format(items_total))
    platform_fee = items_total * 0.08
    delivery_charges = float(data.get('deliverycharges'))
    total_amount = items_total + platform_fee + delivery_charges
    total_amount = float("{:.2f}".format(total_amount))
    order_date = datetime.now().strftime('%d-%m-%Y %H:%M')
    order_day = datetime.now().strftime('%A')
    print('cart')

    order_data = {
        "user_id": user_id,
        "cart_items": data.get("cart"),
        "farmer_amount": items_total,
        "total_amount": total_amount,
        "payment_method": data.get("paymentMethod"),
        "address": data.get("address"),
        "city": data.get("city"),
        "zip": data.get("zip"),
        "email": data.get("email"),
        "phone_number": user_data.get('phone'),
        "delivery_charges": delivery_charges,
        "order_date": order_date,
        "confirmed_date":"",
        "agent_id":"none",
        "pickedup_date":"",
        "delivered_date":"",
        "farmer_otp":"",
        "customer_otp":"",
        "order_day": order_day,
        "status": "ordered"
    }


    orders_collection.insert_one(order_data)

    for item in data.get("cart"):
        product_id = item['productId']
        print(product_id)
        ordered_quantity = float(item['quantity'])

        product = products_collection.find_one({"_id": ObjectId(product_id)})
        if product is None:
            return jsonify({"message": f"Product not found for ID: {product_id}."}), 404
        
        product_quantity = float(product['quantity'])
        if product_quantity < ordered_quantity:
            return jsonify({"message": f"Insufficient stock for product ID: {product_id}."}), 400
        
        updated_quantity = product_quantity - ordered_quantity
        
        result = products_collection.update_one(
            {"_id": ObjectId(product_id)},
            {"$set": {"quantity": updated_quantity}}
        )

        # Check if the product's quantity is now 0 or less
        if result.modified_count > 0 and updated_quantity <= 0:  
            products_collection.delete_one({"_id": ObjectId(product_id)})
            print(f"Product {product_id} deleted due to zero quantity.")

    # Clear the cart for the user
    cart_collection.delete_many({'user_id': user_id})

    return jsonify({"message": "Order placed successfully!"})



@app.route('/get_orders')
def get_orders():
    user_id = session.get('user_id')
    orders = list(orders_collection.find({'user_id':user_id}))
    print(orders)
    for order in orders:
        order['_id']=str(order['_id'])
    return jsonify(orders)

@app.route('/get_farmer_orders', methods=['GET'])
def get_farmer_orders():
    farmer_id = session.get('user_id')
    
    orders = orders_collection.find({'cart_items.farmer_id': farmer_id})
    
    farmer_orders = []
    for order in orders:
        filtered_cart_items = [
            item for item in order['cart_items'] if item['farmer_id'] == farmer_id
        ]
        
        if filtered_cart_items:
            farmer_order = {
                '_id': str(order['_id']),
                'user_id': order['user_id'],
                'cart_items': filtered_cart_items,
                'farmer_amount': sum(item['price'] * item['quantity'] for item in filtered_cart_items),
                'total_amount': order['total_amount'],
                'payment_method': order['payment_method'],
                'address': order['address'],
                'zip': order['zip'],
                'email': order['email'],
                'farmer_otp':order['farmer_otp'],
                'phone_number': order['phone_number'],
                'status': order['status']
            }
            farmer_orders.append(farmer_order)
    
    return jsonify(farmer_orders)


@app.route('/get_agent_orders', methods=['GET'])
def get_agent_orders():
    agent_id = session.get('user_id')
    user_data = users_collection.find_one({'_id': ObjectId(agent_id)})
    agent_location = user_data['location']

    agent_orders = {
        'pending': [],
        'picked_up': [],
        'delivered': []
    }

    pending_orders = orders_collection.find({
        'city': agent_location,
        'status': 'confirmed'
    })
    

     # Process pending orders
    for order in pending_orders:
        cart_items_with_farmers = []
        for item in order['cart_items']:
            farmer_id = item['farmer_id']
            farmer_data = users_collection.find_one({'_id': ObjectId(farmer_id)})
            
            # Append farmer details to each cart item
            if farmer_data:
                cart_items_with_farmers.append({
                    'productId': item['productId'],
                    'name': item['name'],
                    'farmer_id': item['farmer_id'],
                    'image_id': item['image_id'],
                    'price': item['price'],
                    'product_area': item['product_area'],
                    'current_status': item['current_status'],
                    'quantity': item['quantity'],
                    'farmer_area': farmer_data.get('area', 'N/A'),
                    'farmer_location':farmer_data.get('location','N/A'),
                    'farmer_phone': farmer_data.get('phone', 'N/A')
                })
        
        # Append the order with updated cart items to the pending orders list
        agent_order = {
            '_id': str(order['_id']),
            'user_id': order['user_id'],
            'cart_items': cart_items_with_farmers,  # Updated cart items
            'delivery_charges': order['delivery_charges'],
            'total_amount': order['total_amount'],
            'payment_method': order['payment_method'],
            'address': order['address'],
            'zip': order['zip'],
            'email': order['email'],
            'phone_number': order['phone_number'],
            'status': order['status']
        }
        agent_orders['pending'].append(agent_order)

    picked_up_and_delivered_orders = orders_collection.find({
        'city': agent_location,
        'status': {'$in': ['pickedup', 'delivered']},
        'agent_id': agent_id 
    })

    for order in picked_up_and_delivered_orders:
        agent_order = {
            '_id': str(order['_id']),
            'user_id': order['user_id'],
            'cart_items': order['cart_items'],
            'delivery_charges': order['delivery_charges'],
            'total_amount': order['total_amount'],
            'payment_method': order['payment_method'],
            'address': order['address'],
            'zip': order['zip'],
            'email': order['email'],
            'phone_number': order['phone_number'],
            'status': order['status']
        }
        if order['status'] == 'pickedup':
            agent_orders['picked_up'].append(agent_order)
        elif order['status'] == 'delivered':
            agent_orders['delivered'].append(agent_order)

    return jsonify(agent_orders)

@app.route('/generate_invoice/<order_id>', methods=['GET'])
def generate_invoice(order_id):
    user_id = session.get('user_id')
    
    order = orders_collection.find_one({'_id': ObjectId(order_id)})
    user_data = users_collection.find_one({'_id': ObjectId(user_id)})

    if not order:
        return jsonify({'error': 'Order not found'}), 404
    
    if not user_data:
        return jsonify({'error': 'User not found'}), 404

    # Calculate values for invoice
    platform_fee = order['farmer_amount'] * 0.08
    platform_fee = "{:.2f}".format(platform_fee)
    delivery_charges = "{:.2f}".format(order['delivery_charges'])

    return render_template(
        'invoice.html',
        order_id=order_id,
        user_name=user_data['name'],
        address=order['address'],
        email=user_data['email'],
        phone=user_data['phone'],
        ordered_date=order['order_date'],
        items=order['cart_items'],
        items_total=order['farmer_amount'],
        platform_fee=platform_fee,
        delivery_charges=delivery_charges,
        total_amount=order['total_amount'],
        payment_method=order['payment_method'],
        status=order['status'].title()
    )


@app.route('/get_order_status/<order_id>', methods=['GET'])
def get_order_status(order_id):
    order = orders_collection.find_one({'_id': ObjectId(order_id)})
    if not order:
        return jsonify({'error': 'Order not found'}), 404
    
    status=order['status']
    ordered_date=order['order_date']
    confirmed_date=order['confirmed_date']
    pickedup_date=order['pickedup_date']
    delivered_date=order['delivered_date']
    customer_otp=order['customer_otp']    
    return jsonify({'status':status,'ordered_date':ordered_date,'confirmed_date':confirmed_date,'pickedup_date':pickedup_date,'delivered_date':delivered_date,'customer_otp':customer_otp})

@app.route('/accept_order/<order_id>', methods=['POST'])
def accept_order(order_id):
    try:
        user_id = session['user_id']
        farmer_otp = random.randint(100000, 999999)
        result = orders_collection.update_one(
            {'_id': ObjectId(order_id), 'cart_items.farmer_id': user_id},
            {'$set': {'cart_items.$[elem].current_status': 'accepted'}},
            
            array_filters=[{'elem.farmer_id': user_id}]
        )
        orders_collection.update_one({'_id':ObjectId(order_id)},{'$set':{'farmer_otp': farmer_otp}})
        if result.modified_count > 0:
            order = orders_collection.find_one({'_id': ObjectId(order_id)})
            all_accepted = all(
                item.get('current_status') == 'accepted' 
                for item in order.get('cart_items', [])
            )

            if all_accepted:
                confirmed_date = datetime.now().strftime('%d-%m-%Y %H:%M')
                orders_collection.update_one(
                    {'_id': ObjectId(order_id)},
                    {'$set': {'status': 'confirmed', 'confirmed_date': confirmed_date}}
                )

        return jsonify({'success':True, 'message': 'Order accepted successfully!'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    
@app.route('/pickup_order/<order_id>', methods=['POST'])
def pickup_order(order_id):
    data = request.json
    entered_otp = int(data.get('otp'))
    agent_id = session.get('user_id')
    order = orders_collection.find_one({'_id': ObjectId(order_id)})
    
    if not order:
        return jsonify({'message': 'Order not found'}), 404
    stored_otp = int(order.get('farmer_otp'))  
    print(entered_otp,stored_otp)

    if entered_otp != stored_otp:
        return jsonify({'message': 'Invalid OTP'}), 400
    pickedup_date = datetime.now().strftime('%d-%m-%Y %H:%M')
    user_otp = random.randint(100000, 999999)

    result = orders_collection.update_one(
        {'_id': ObjectId(order_id)},
        {'$set': {'status': 'pickedup','pickedup_date':pickedup_date,"customer_otp":user_otp,'agent_id': str(agent_id)}}
    )

    if result.modified_count > 0:
        return jsonify({'message': 'Order picked up successfully'}), 200
    else:
        return jsonify({'message': 'Order status could not be updated'}), 500



@app.route('/deliver_order/<order_id>', methods=['POST'])
def deliver_order(order_id):
    data = request.json
    entered_otp = int(data.get('otp'))
    order = orders_collection.find_one({'_id': ObjectId(order_id)})
    
    if not order:
        return jsonify({'message': 'Order not found'}), 404
    
    stored_otp = int(order.get('customer_otp')) 

    if entered_otp != stored_otp:
        return jsonify({'message': 'Invalid OTP'}), 400
    delivered_date = datetime.now().strftime('%d-%m-%Y %H:%M')
    
    result = orders_collection.update_one(
        {'_id': ObjectId(order_id)},
        {'$set': {'status': 'delivered','delivered_date':delivered_date}}
    )

    if result.modified_count > 0:
        return jsonify({'success': True, 'message': 'Order delivered successfully'}), 200
    else:
        return jsonify({'success': False, 'message': 'Order status could not be updated'}), 500
    
@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    try:
        data = request.get_json()
        name = data.get('name')
        email = data.get('email')
        orderid = data.get('orderId')
        feedback = data.get('feedback')

        if not name or not email or not feedback:
            return jsonify({"success": False, "message": "All fields are required"}), 400

        feedback = {
            "name": name,
            "email": email,
            "orderid": orderid,
            "feedback": feedback,
            "reply": "",
            "status": "pending",
            "submitted_at": datetime.now()
        }

        feedback_collection.insert_one(feedback)

        return jsonify({"success": True, "message": "Feedback submitted successfully"}), 200

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"success": False, "message": "An error occurred while submitting feedback"}), 500
    
@app.route('/api/feedbacks/pending', methods=['GET'])
def get_pending_feedbacks():
    pending_feedbacks = list(feedback_collection.find({'status': 'pending'}, {'_id': 1, 'orderid': 1, 'name': 1, 'feedback': 1}))
    for feedback in pending_feedbacks:
        feedback['_id'] = str(feedback['_id'])
    return jsonify(pending_feedbacks)

@app.route('/api/feedbacks/sent', methods=['GET'])
def get_sent_feedbacks():
    sent_feedbacks = list(feedback_collection.find({'status': 'sent'}, {'_id': 1, 'orderid': 1, 'name': 1, 'feedback': 1, 'reply': 1}))
    for feedback in sent_feedbacks:
        feedback['_id'] = str(feedback['_id'])
    return jsonify(sent_feedbacks)

@app.route('/api/feedbacks/<feedback_id>/reply', methods=['POST'])
def send_reply(feedback_id):
    data = request.get_json()
    print(data)
    reply_text = data.get('reply_text', '').strip()
    feedback = feedback_collection.find_one({'_id':ObjectId(feedback_id)})
    if not reply_text:
        return jsonify({'message': 'Reply cannot be empty.'}), 400

    result = feedback_collection.update_one(
        {'_id': ObjectId(feedback_id), 'status': 'pending'},
        {'$set': {'reply': reply_text, 'status': 'sent'}}
    )

    if result.modified_count == 1:
        send_reply_to_email(feedback,reply_text)
        return jsonify({'message': 'Reply sent successfully!'}), 200
    return jsonify({'message': 'Feedback not found or already replied.'}), 404

@app.route('/api/users/farmers', methods=['GET'])
def get_farmers():
    farmers = list(users_collection.find({'role': 'farmer'}))
    
    for farmer in farmers:
        farmer['_id'] = str(farmer['_id'])  
        farmer['blocked'] = farmer.get('blocked', False)
    
    return jsonify(farmers)

@app.route('/api/users/<user_id>/toggleBlock', methods=['PATCH'])
def toggle_block(user_id):
    user = users_collection.find_one({'_id': ObjectId(user_id)})
    
    if user:
        blocked = user.get('blocked', False)
        users_collection.update_one(
            {'_id': ObjectId(user_id)},
            {'$set': {'blocked': not blocked}}
        )
        return jsonify({'success': True, 'blocked': not blocked})
    
    return jsonify({'success': False}), 404

@app.route('/order/<order_id>', methods=['GET'])
def check_order(order_id):
    print("orderid",order_id)
    order = orders_collection.find_one({"_id": ObjectId(order_id)}) 
    order['_id']=str(order['_id'])
    if order:
        return jsonify(order)
    return jsonify({"message": "Order not found"}), 404

@app.route('/customer_upload_profile_image', methods=['POST'])
def customer_upload_profile_image():
    if 'profile_image' not in request.files:
        return redirect(request.url)
    
    file = request.files['profile_image']
    email = request.form['profile_email']
    print(email)

    if file.filename == '':
        return redirect(request.url)

    if file:
        filename = secure_filename(file.filename)
        unique_filename = f"{int(time.time())}_{filename}"
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        try:
            file.save(file_path)  
            print(f"File saved successfully: {file_path}")

        
            db.users.update_one(
                {'email': email},  
                {'$set': {'profile_image': f'static/uploads/{unique_filename}'}}
            )
        except Exception as e:
            print(f"Error saving file: {e}")  


        db.users.update_one(
            {'email': email},
            {'$set': {'profile_image': f'/static/uploads/{unique_filename}'}}
        )

    return redirect(url_for('customerpagerender'))

@app.route('/farmer_upload_profile_image', methods=['POST'])
def farmer_upload_profile_image():
    if 'profile_image' not in request.files:
        return redirect(request.url)
    
    file = request.files['profile_image']
    email = request.form['profile_email']
    print(email)

    if file.filename == '':
        return redirect(request.url)

    if file:
        filename = secure_filename(file.filename)
        unique_filename = f"{int(time.time())}_{filename}"
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        try:
            file.save(file_path)  
            print(f"File saved successfully: {file_path}")

        
            db.users.update_one(
                {'email': email},  
                {'$set': {'profile_image': f'static/uploads/{unique_filename}'}}
            )
        except Exception as e:
            print(f"Error saving file: {e}")  


        db.users.update_one(
            {'email': email},
            {'$set': {'profile_image': f'/static/uploads/{unique_filename}'}}
        )

    return redirect(url_for('farmerpagerender'))

@app.route('/agent_upload_profile_image', methods=['POST'])
def agent_upload_profile_image():
    if 'profile_image' not in request.files:
        return redirect(request.url)
    
    file = request.files['profile_image']
    email = request.form['profile_email']
    print(email)

    if file.filename == '':
        return redirect(request.url)

    if file:
        filename = secure_filename(file.filename)
        unique_filename = f"{int(time.time())}_{filename}"
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        try:
            file.save(file_path)  
            print(f"File saved successfully: {file_path}")

        
            db.users.update_one(
                {'email': email},  
                {'$set': {'profile_image': f'static/uploads/{unique_filename}'}}
            )
        except Exception as e:
            print(f"Error saving file: {e}")  


        db.users.update_one(
            {'email': email},
            {'$set': {'profile_image': f'/static/uploads/{unique_filename}'}}
        )

    return redirect(url_for('agentpagerender'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
